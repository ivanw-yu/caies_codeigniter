<?php

  class Members extends CI_Controller{

    public function index(){

    }

    public function view($id){

    }

    public function edit($id){

    }

    public function delete($id){

    }

    public function dashboard(){
      $this->load->view("templates/header");
      $this->load->view("pages/dashboard");
      $this->load->view("templates/footer");
    }

  }


 ?>
