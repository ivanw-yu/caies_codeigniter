<?php

  class Replies extend CI_Controller{

    // public function index(){
    //
    // }
    //
    // public function view($id){
    //
    // }

    public function edit($id){

    }

    public function delete($id){

    }

  }


 ?>
